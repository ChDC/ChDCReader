"use strict";

requirejs(["config"], function () {
  requirejs(["main"]);
});